create
    definer = podopro_dev_user@`%` procedure pain_migration()
BEGIN
DECLARE commnt LONGTEXT;
	DECLARE cur_painId BIGINT;
	DECLARE cursor_List_isdone BOOLEAN DEFAULT FALSE;
	DECLARE cursor_List CURSOR FOR
      SELECT id from medical_record_pain;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_List_isdone = TRUE;

    OPEN cursor_List;
	loop_List: LOOP
      FETCH cursor_List INTO cur_painId;
      IF cursor_List_isdone THEN
         LEAVE loop_List;
      END IF;

		# hows
		set commnt = (select GROUP_CONCAT(`comment` SEPARATOR  ', ')
		from medical_record_pain_how
			where MEDICAL_RECORD_PAIN_ID = cur_painId and `comment` is not NUll and `comment` <>''
		group by MEDICAL_RECORD_PAIN_ID);
		update medical_record_pain set how_comment = commnt where ID = cur_painId;

        # Where
        set commnt = (select GROUP_CONCAT(CUSTOM_VALUE SEPARATOR  ', ')
		from medical_record_pain_where
			where MEDICAL_RECORD_PAIN_ID = cur_painId and CUSTOM_VALUE is not NUll and CUSTOM_VALUE <>''
		group by MEDICAL_RECORD_PAIN_ID);
		update medical_record_pain set where_comment = commnt where ID = cur_painId;

		# When
        set commnt = (select GROUP_CONCAT(CUSTOM_VALUE SEPARATOR  ', ')
		from medical_record_pain_when
			where MEDICAL_RECORD_PAIN_ID = cur_painId and CUSTOM_VALUE is not NUll and CUSTOM_VALUE <>''
		group by MEDICAL_RECORD_PAIN_ID);
		update medical_record_pain set when_comment = commnt where ID = cur_painId;
   END LOOP loop_List;

   CLOSE cursor_List;
END;

