create
    definer = podopro_dev_user@`%` procedure practitioner_check_partner_types()
BEGIN

	DECLARE cur_id BIGINT;
    DECLARE cur_accountId BIGINT;
    DECLARE cur_partnerId BIGINT;

	DECLARE cursor_List_isdone BOOLEAN DEFAULT FALSE;
    DECLARE cursor_List CURSOR FOR 
      SELECT ID, ACCOUNT_ID,  partner_id from colleague order by ID;


   DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_List_isdone = TRUE;   
   
   set @partnerTypePractitioner = (select ID from lov_value where VALUE = 'PARTNER_TYPE_PRACTITIONER');
   set @partnerTypeProspect = (select ID from lov_value where VALUE = 'PARTNER_TYPE_PROSPECT');

   
   OPEN cursor_List;

   loop_List: LOOP
		  FETCH cursor_List INTO cur_id, cur_accountId, cur_partnerId;
		  IF cursor_List_isdone THEN
			 LEAVE loop_List;
		  END IF;
          
		set @partner_type_practionner = (select id from partner_type t 
			where t.partner_id = cur_partnerId 
				and type_lov_value_id = @partnerTypePractitioner
                and main = b'1');
		if @partner_type_practionner is NULL THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No practitioner main type';
		end if;
	
    set @partner_type_prospect = (select id from partner_type t where t.partner_id = cur_partnerId and type_lov_value_id = @partnerTypeProspect);
		if @partner_type_prospect is NULL THEN
			insert into partner_type (partner_id, type_lov_value_id, version, main) values (cur_partnerId, @partnerTypeProspect, 1, b'0');
		end if;
    
    
   END LOOP loop_List;

   CLOSE cursor_List;
END;

