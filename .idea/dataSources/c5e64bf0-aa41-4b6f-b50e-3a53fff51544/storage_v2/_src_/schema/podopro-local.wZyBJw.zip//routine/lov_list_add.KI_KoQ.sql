create
    definer = podopro_dev_user@`%` procedure lov_list_add(IN lovListName varchar(255), IN lovListLabel varchar(100))
BEGIN
insert into lov_list (VERSION, NAME, LABEL) values (1, lovListName, lovListLabel);
END;

