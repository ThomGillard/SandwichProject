create
    definer = podopro_dev_user@`%` procedure migration_practitioner_to_partner(IN LIMIT_FROM int, IN LIMIT_TO int)
BEGIN

	DECLARE cur_id BIGINT;
    DECLARE cur_accountId BIGINT;
    DECLARE cur_patienOfficeId BIGINT;
    DECLARE cur_patienCreationUserId BIGINT;
    DECLARE cur_partnerId BIGINT;

	DECLARE cursor_List_isdone BOOLEAN DEFAULT FALSE;
    DECLARE cursor_List CURSOR FOR 
      SELECT ID, ACCOUNT_ID from colleague where partner_id is NULL limit LIMIT_FROM, LIMIT_TO;


   DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_List_isdone = TRUE;   
   
   set @addressType = (select ID from lov_value where VALUE = 'PARTNER_ADDRESS_MAIN');
   set @partnerTypeCustomer = (select ID from lov_value where VALUE = 'PARTNER_TYPE_PRACTITIONER');
   -- set @partnerTypeProspect = (select ID from lov_value where VALUE = 'PARTNER_TYPE_PROSPECT');
   
   OPEN cursor_List;

   loop_List: LOOP
		  FETCH cursor_List INTO cur_id, cur_accountId;
		  IF cursor_List_isdone THEN
			 LEAVE loop_List;
		  END IF;
      
		set @user_id = (select ID from user where ACCOUNT_ID = cur_accountId LIMIT 0, 1);
		-- Create partner
		INSERT INTO partner (`version`, `name`, `account_id`, creation_date, update_date, creation_user_id)
		select 1, NAME, ACCOUNT_ID, NOW(), NOW(), @user_id  from colleague  where ID = cur_id;
		
		set @partnerId = (SELECT LAST_INSERT_ID());
		UPDATE colleague set partner_id = @partnerId where ID = cur_id;
        
        insert into partner_type values (@partnerId, @partnerTypeCustomer);
        -- insert into partner_type values (@partnerId, @partnerTypeProspect);
		
		-- Create person
		INSERT INTO `person` (`version`, `creation_date`, `update_date`, `civility`, `email`, `last_name`, `mobile_phone`, `office_phone`, `rgpd`, `creation_user_id`, `account_id`)
		select 1, NOW(), NOW(), 'MR', EMAIL, NAME, PHONE2, PHONE, b'1', @user_id, ACCOUNT_ID from colleague where id = cur_id;
		set @personId = (SELECT LAST_INSERT_ID());
		
		-- Add person to partner
		INSERT INTO `partner_person`(`version`,`creation_date`, `update_date`, `creation_user_id`, `partner_id`, `person_id`)
		VALUES (1, NOW(), NOW(), @user_id, @partnerId, @personId);
        
        -- Address
		insert into address (version, creation_date, update_date, country, locality, `number`, street, zip_code, creation_user_id)
		select 1, NOW(), NOW(), ADDRESS_COUNTRY, ADDRESS_LOCALITY, ADDRESS_NUMBER, ADDRESS_STREET, ADDRESS_ZIP_CODE, @user_id from colleague where id = cur_id; 
		set @addressId = (SELECT LAST_INSERT_ID());
	
		-- Add address to partner
		insert into partner_address (version, creation_date, update_date, creation_user_id, address_id, partner_id, type_lov_value_id)
		values (1, NOW(), NOW(), @user_id, @addressId, @partnerId, @addressType);
	
        
        update colleague set partner_id = @partnerId where id = cur_id;
	
   END LOOP loop_List;

   CLOSE cursor_List;
END;

