create
    definer = podopro_dev_user@`%` procedure lov_value_add(IN lovListName varchar(255), IN lovValueValue varchar(255),
                                                           IN lovValueLabel varchar(255))
BEGIN
	set @lovListId = (select ID from lov_list where NAME = lovListName);
    insert into lov_value (VERSION, VALUE, LABEL, LOV_LIST_ID) values (1, lovValueValue, lovValueLabel, @lovListId);
END;

