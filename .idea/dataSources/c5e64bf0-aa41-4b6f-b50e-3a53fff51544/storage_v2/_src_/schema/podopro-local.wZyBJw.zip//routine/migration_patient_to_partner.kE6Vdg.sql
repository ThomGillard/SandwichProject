create
    definer = podopro_dev_user@`%` procedure migration_patient_to_partner(IN LIMIT_FROM int, IN LIMIT_TO int)
BEGIN
	DECLARE cur_patientId BIGINT;
    DECLARE cur_patienCreationDate DATETIME;
    DECLARE cur_patienUpdateDate DATETIME;
    DECLARE cur_patienFirstName VARCHAR(100);
    DECLARE cur_patienLastName VARCHAR(100);
    DECLARE cur_patienAccountId BIGINT;
    DECLARE cur_patienOfficeId BIGINT;
    DECLARE cur_patienCreationUserId BIGINT;
    DECLARE cur_partnerId BIGINT;

	DECLARE cursor_List_isdone BOOLEAN DEFAULT FALSE;
    DECLARE cursor_List CURSOR FOR 
      SELECT id,
			FIRST_NAME,
            LAST_NAME, 
            ACCOUNT_ID,
            OFFICE_ID,
            partner_id,
            CREATION_DATE,
            UPDATE_DATE,
            CREATION_USER_ID
            from patient where partner_id is NULL limit LIMIT_FROM, LIMIT_TO;


   DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_List_isdone = TRUE;   
   
   set @addressType = (select ID from lov_value where VALUE = 'PARTNER_ADDRESS_INVOICE');
   set @partnerTypeCustomer = (select ID from lov_value where VALUE = 'PARTNER_TYPE_CUSTOMER');
   
   OPEN cursor_List;

   loop_List: LOOP
      FETCH cursor_List INTO cur_patientId, cur_patienFirstName, cur_patienLastName, cur_patienAccountId, cur_patienOfficeId, cur_partnerId, cur_patienCreationDate, cur_patienUpdateDate, cur_patienCreationUserId;
      IF cursor_List_isdone THEN
         LEAVE loop_List;
      END IF;
      
      IF cur_partnerId is NULL THEN
		INSERT INTO partner (`version`, `name`, `account_id`, `office_id`, creation_date, update_date, creation_user_id) VALUES (1, CONCAT(cur_patienLastName, " ", cur_patienFirstName), cur_patienAccountId, cur_patienOfficeId, cur_patienCreationDate, cur_patienUpdateDate, cur_patienCreationUserId);
		set cur_partnerId = (SELECT LAST_INSERT_ID());
        UPDATE patient set partner_id = cur_partnerId where ID = cur_patientId;
        
        insert into partner_type values (cur_partnerId, @partnerTypeCustomer);
        
        -- Create person
        INSERT INTO `person` (`version`, `creation_date`, `update_date`, `birth_date`, `civility`, `email`, `first_name`, `job`, `last_name`, `mobile_phone`, `office_phone`, `phone`, `rgpd`, `creation_user_id`, `account_id`)
		select 1, CREATION_DATE, UPDATE_DATE, BIRTH_DATE, CIVILITY, EMAIL, FIRST_NAME, PROFESSION, LAST_NAME, PHONE_MOBILE, PHONE_OFFICE, PHONE_PRIVATE, b'1', CREATION_USER_ID, ACCOUNT_ID from patient where id = cur_patientId;
        set @personId = (SELECT LAST_INSERT_ID());
        
        -- Add person to partner
        INSERT INTO `partner_person`(`version`,`creation_date`, `update_date`, `creation_user_id`, `partner_id`, `person_id`)
		VALUES (1, cur_patienCreationDate, cur_patienUpdateDate, cur_patienCreationUserId, cur_partnerId, @personId);
        
        -- Address
        insert into address (version, creation_date, update_date, country, locality, `number`, street, zip_code, creation_user_id)
        select 1, CREATION_DATE, UPDATE_DATE, ADDRESS_COUNTRY, ADDRESS_LOCALITY, ADDRESS_NUMBER, ADDRESS_STREET, ADDRESS_ZIP_CODE, cur_patienCreationUserId from patient where id = cur_patientId; 
        set @addressId = (SELECT LAST_INSERT_ID());
        
        -- Add address to partner
        insert into partner_address (version, creation_date, update_date, creation_user_id, address_id, partner_id, type_lov_value_id)
        values (1, cur_patienCreationDate, cur_patienUpdateDate, cur_patienCreationUserId, @addressId, cur_partnerId, @addressType);
        
      END IF;
	
      
   END LOOP loop_List;

   CLOSE cursor_List;
END;

