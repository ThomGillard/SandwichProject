create
    definer = podopro_dev_user@`%` procedure billable_action_first_visit_migration()
BEGIN
   DECLARE cursor_List_isdone BOOLEAN DEFAULT FALSE;

   DECLARE lovValueId BIGINT;
   DECLARE minDate DATETIME;
   DECLARE cur_patientId BIGINT;
   DECLARE cur_email VARCHAR(250) DEFAULT '';

   DECLARE cursor_List CURSOR FOR
      SELECT id from patient;

   DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_List_isdone = TRUE;

   set lovValueId = (select id from lov_value where VALUE = 'FIRST_VISIT');

   OPEN cursor_List;

   loop_List: LOOP
      FETCH cursor_List INTO cur_patientId;
      IF cursor_List_isdone THEN
         LEAVE loop_List;
      END IF;

	SET minDate = (select min(DATE) from billable_action where PATIENT_ID =  cur_patientId);

    insert into billable_action_label (BILLABLE_ACTION_ID, LOV_VALUE_ID)
    select a.ID, lovValueId from billable_action a
		left join billable_action_label l on l.BILLABLE_ACTION_ID = a.ID
        left join lov_value v on v.ID = l.LOV_VALUE_ID
		where a.PATIENT_ID = cur_patientId AND a.DATE = minDate and l.LOV_VALUE_ID IS NULL;
   END LOOP loop_List;

   CLOSE cursor_List;
END;

